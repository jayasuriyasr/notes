# Markdown Documentation Platform

A multi-author documentation platform. Anyone can register and write Markdown in a
hierarchical tree, choose who may see or edit each page, and publish at clean nested URLs.

```
/system-design
/system-design/rate-limiter
/system-design/rate-limiter/token-bucket
```

**React 19 (Vite) · Tailwind CSS v4 · Supabase (PostgreSQL + Auth + RLS) · Vercel**

Read [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the design, the rejected alternatives and
the reasoning behind every significant decision.

---

## What it does

**Readers** get a sidebar tree, breadcrumbs, an on-page table of contents with scroll spy,
previous/next navigation, full-text search (⌘K), dark mode, and a responsive layout.
No account required.

**Members** register at `/register` and get a dashboard: a split-pane Markdown editor with
live preview, drag-free reordering, re-parenting, guarded deletion — and for every page,
one of three access levels:

| Setting | Who reads | Who edits |
|---|---|---|
| 🔒 **Private** | you and administrators | you and administrators |
| 👁 **Anyone can view** | everyone | you and administrators |
| ✎ **Anyone can edit** | everyone | any signed-in member |

A private section hides everything inside it, whatever the pages within say — so
"private" always means the whole subtree. Opening the section back up restores each page
to its own setting.

**Administrators** additionally see every page in the system and a **People** page:
promote and demote, suspend (reversible, keeps all their content) and delete. Deleting an
account transfers its pages rather than destroying them.

**The database** does the hard parts. URLs are derived from the hierarchy by trigger;
renames and moves rewrite every descendant and record redirects automatically; and every
permission decision is a Row Level Security policy, not a frontend check.

---

## Setup

### 1. Install

```bash
npm install
cp .env.example .env
```

### 2. Create a Supabase project

At [supabase.com](https://supabase.com), then fill in `.env` from
**Project Settings → API**:

```env
VITE_SUPABASE_URL=https://<your-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<your anon key>
VITE_SITE_URL=http://localhost:5173
VITE_SITE_NAME=Documentation
```

> Both values are public — Vite inlines them into the bundle. That is fine: the anon key
> grants nothing on its own, it only identifies the request as the `anon` Postgres role,
> and every permission decision is made afterwards by RLS.
>
> **Never add `SUPABASE_SERVICE_ROLE_KEY` to this file.** It bypasses RLS entirely.

### 3. Apply the database

With the Supabase CLI:

```bash
supabase link --project-ref <your-ref>
supabase db push
psql "$DATABASE_URL" -f supabase/seed.sql     # optional sample content
```

Or paste each file into the SQL editor **in order**:

```
supabase/migrations/20260831120000_schema.sql
supabase/migrations/20260831120100_functions.sql
supabase/migrations/20260831120150_admin.sql
supabase/migrations/20260831120200_rls.sql
supabase/migrations/20260831120300_indexes.sql
```

Or paste **`supabase/schema.sql`** — all five concatenated in order, for one run.

Run `supabase/seed.sql` afterwards for sample content; it adopts your account as the owner,
so create one first.

> **Already applied an earlier version of this schema?** The multi-user model replaces
> `topics.status` with ownership and visibility, so start clean:
> ```sql
> drop table if exists public.topic_redirects, public.topics, public.profiles cascade;
> drop view if exists public.public_profiles;
> ```
> then re-run the migrations.

### 4. Create the first administrator

Registration is open, so just sign up at `/register`. Then promote yourself once, in the
SQL editor:

```sql
update public.profiles set role = 'admin' where email = 'you@example.com';
```

Every new account is `('member','active')` — the signup trigger never reads a role from
the payload, which is why open registration cannot mint an administrator no matter what a
client posts. `role` and `status` are not writable through the API at all; after this one
statement, administrators promote each other from the **People** page.

### 5. Run

```bash
npm run dev          # http://localhost:5173
```

Register at `/register`, write at `/dashboard`, manage people at `/dashboard/people`.

---

## Deploying to Vercel

1. Import the repository. Vercel detects Vite; the defaults are correct.
2. Add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_SITE_URL`, `VITE_SITE_NAME`
   under **Settings → Environment Variables**.
3. Deploy. `vercel.json` already handles the SPA fallback (so a hard refresh on a deep URL
   works), immutable asset caching, and security headers including a CSP.
4. Set your custom domain, then update `VITE_SITE_URL` **and** the Supabase **Site URL**.

To keep `sitemap.xml` fresh between deploys, add a Supabase **Database Webhook** on
`topics` pointing at a Vercel **Deploy Hook**.

---

## Scripts

| Command | Does |
|---|---|
| `npm run dev` | Dev server with HMR |
| `npm run build` | Production build, then generate `sitemap.xml` + `robots.txt` |
| `npm run preview` | Serve the production build locally |

---

## Project layout

```
src/
├── components/  markdown/ · docs/ · admin/ · ui/
├── layouts/     DocsLayout · DashboardLayout (+ RequireMember)
├── pages/       HomePage · DocPage · AuthPage · dashboard/*
├── routes/      the whole route table
├── hooks/       useAuth · useTheme · useTopics · useDebounced
├── services/    topics.js · admin.js  ← the only modules that talk to the database
├── lib/         supabase · config · errors · queryClient
└── utils/       slug · tree · markdown

supabase/migrations/   schema → functions → admin → rls → indexes
scripts/               generate-sitemap.mjs
tests/                 SQL, XSS and browser suites (see tests/README.md)
```

---

## How it works, briefly

**URLs.** `topics.parent_id` is the source of truth for structure; `topics.path` is a
trigger-maintained cache of the full URL with a `UNIQUE` index on it. A page lookup is one
index probe, breadcrumbs are prefix probes against the same index, and no recursive query
runs on the read path. Clients cannot write `path` — a trigger recomputes it on every
write.

**Renames and moves.** Changing a slug or a parent rewrites every descendant's path in one
statement and records the old path in `topic_redirects`. The SPA consults that table before
rendering 404, so old links keep working. Redirects point at a topic **id**, so a page
renamed three times still resolves in one hop.

**Access.** Each page stores the owner's chosen `visibility` and a trigger-derived
`effective_visibility` — the same value after the "most restrictive ancestor wins" rule is
applied. Policies read only the derived column, so an access check is one indexed
comparison rather than a walk up the tree.

**Security.** `anon` is granted `SELECT` only, and RLS restricts that to
`effective_visibility <> 'private'`. Writes go through `is_active()` (a suspended account
becomes an ordinary reader while keeping all its pages) and `is_admin()`, both
`SECURITY DEFINER` with a pinned `search_path`. On a page anyone can edit, a guest may
change the title and text — a request that would also rename it, move it, change its
visibility or transfer ownership is refused by a trigger, because a policy cannot see the
old row. The React guards control what renders, not what is permitted: remove them and a
member still sees non-private pages plus their own, and every write is still refused.

**Deletion.** The self-referencing foreign key uses `NO ACTION`, which is checked at end of
statement. Deleting a page that has children fails; deleting the page *and its whole
subtree in one statement* succeeds. Accidents are blocked, intent is honoured.

**Markdown.** `remark-gfm` → `rehype-slug` → `rehype-highlight` → `rehype-sanitize`, in
that order. Sanitising last means plugin output is vetted too. Raw HTML is never
interpreted.

---

## Testing

74 SQL checks, 30 Markdown security checks and 95 browser checks run against a local
PostgreSQL and a small Supabase stand-in — no cloud project needed. The stand-in runs
every request as the real `anon` or `authenticated` role, so the browser suites exercise
the actual RLS policies rather than mocks. See [`tests/README.md`](./tests/README.md).

---

## License

MIT
