# Markdown Documentation Platform

A production-ready documentation site: administrators write Markdown in a hierarchical
tree; everyone else reads the published pages at clean, nested URLs.

```
/system-design
/system-design/rate-limiter
/system-design/rate-limiter/token-bucket
```

**React 19 (Vite) · Tailwind CSS v4 · Supabase (PostgreSQL + Auth + RLS) · Vercel**

Read [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the design, the rejected alternatives and
the reasoning behind every significant decision.

---

## What it does

**Readers** get a sidebar tree, breadcrumbs, an on-page table of contents with scroll spy,
previous/next navigation, full-text search (⌘K), dark mode, and a responsive layout.
No account required.

**Administrators** get a dashboard with the full tree including drafts, a split-pane
Markdown editor with live preview, publish/unpublish, slug editing, drag-free reordering,
re-parenting, and guarded deletion.

**The database** does the hard parts: URLs are derived from the hierarchy by trigger,
renames and moves rewrite every descendant and record redirects automatically, and
authorization is enforced by Row Level Security rather than by frontend checks.

---

## Setup

### 1. Install

```bash
npm install
cp .env.example .env
```

### 2. Create a Supabase project

At [supabase.com](https://supabase.com), then fill in `.env` from
**Project Settings → API**:

```env
VITE_SUPABASE_URL=https://<your-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<your anon key>
VITE_SITE_URL=http://localhost:5173
VITE_SITE_NAME=Documentation
```

> Both values are public — Vite inlines them into the bundle. That is fine: the anon key
> grants nothing on its own, it only identifies the request as the `anon` Postgres role,
> and every permission decision is made afterwards by RLS.
>
> **Never add `SUPABASE_SERVICE_ROLE_KEY` to this file.** It bypasses RLS entirely.

### 3. Apply the database

With the Supabase CLI:

```bash
supabase link --project-ref <your-ref>
supabase db push
psql "$DATABASE_URL" -f supabase/seed.sql     # optional sample content
```

Or paste each file into the SQL editor **in order**:

```
supabase/migrations/20260831120000_schema.sql
supabase/migrations/20260831120100_functions.sql
supabase/migrations/20260831120200_rls.sql
supabase/migrations/20260831120300_indexes.sql
supabase/seed.sql          (optional)
```

### 4. Create an administrator

Add a user in **Authentication → Users** (set a password, mark the email confirmed), then
promote them in the SQL editor:

```sql
update public.profiles set role = 'admin' where email = 'you@example.com';
```

A new signup is always `viewer`. Promotion is deliberately impossible through the API —
there is no write policy on `profiles`, plus a guard trigger. Only the project owner can
do it.

### 5. Run

```bash
npm run dev          # http://localhost:5173
```

Sign in at `/login`, manage content at `/admin`.

---

## Deploying to Vercel

1. Import the repository. Vercel detects Vite; the defaults are correct.
2. Add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_SITE_URL`, `VITE_SITE_NAME`
   under **Settings → Environment Variables**.
3. Deploy. `vercel.json` already handles the SPA fallback (so a hard refresh on a deep URL
   works), immutable asset caching, and security headers including a CSP.
4. Set your custom domain, then update `VITE_SITE_URL` **and** the Supabase **Site URL**.

To keep `sitemap.xml` fresh between deploys, add a Supabase **Database Webhook** on
`topics` pointing at a Vercel **Deploy Hook**.

---

## Scripts

| Command | Does |
|---|---|
| `npm run dev` | Dev server with HMR |
| `npm run build` | Production build, then generate `sitemap.xml` + `robots.txt` |
| `npm run preview` | Serve the production build locally |

---

## Project layout

```
src/
├── components/  markdown/ · docs/ · admin/ · ui/
├── layouts/     DocsLayout · AdminLayout (+ RequireAdmin)
├── pages/       HomePage · DocPage · LoginPage · admin/*
├── routes/      the whole route table
├── hooks/       useAuth · useTheme · useTopics · useDebounced
├── services/    topics.js  ← the only module that talks to the database
├── lib/         supabase · config · errors · queryClient
└── utils/       slug · tree · markdown

supabase/migrations/   schema → functions → rls → indexes
scripts/               generate-sitemap.mjs
tests/                 SQL, XSS and browser suites (see tests/README.md)
```

---

## How it works, briefly

**URLs.** `topics.parent_id` is the source of truth for structure; `topics.path` is a
trigger-maintained cache of the full URL with a `UNIQUE` index on it. A page lookup is one
index probe, breadcrumbs are prefix probes against the same index, and no recursive query
runs on the read path. Clients cannot write `path` — a trigger recomputes it on every
write.

**Renames and moves.** Changing a slug or a parent rewrites every descendant's path in one
statement and records the old path in `topic_redirects`. The SPA consults that table before
rendering 404, so old links keep working. Redirects point at a topic **id**, so a page
renamed three times still resolves in one hop.

**Security.** `anon` is granted `SELECT` only; RLS restricts that to
`status = 'published'`. Admin writes require `public.is_admin()`, a `SECURITY DEFINER`
function with a pinned `search_path`. The React admin guard controls what renders, not what
is permitted — remove it and a non-admin still sees published rows and nothing else.

**Deletion.** The self-referencing foreign key uses `NO ACTION`, which is checked at end of
statement. Deleting a page that has children fails; deleting the page *and its whole
subtree in one statement* succeeds. Accidents are blocked, intent is honoured.

**Markdown.** `remark-gfm` → `rehype-slug` → `rehype-highlight` → `rehype-sanitize`, in
that order. Sanitising last means plugin output is vetted too. Raw HTML is never
interpreted.

---

## Testing

29 SQL behaviour checks, 30 Markdown security checks, and 56 browser checks run against a
local PostgreSQL and a small Supabase stand-in — no cloud project needed.
See [`tests/README.md`](./tests/README.md).

---

## License

MIT
